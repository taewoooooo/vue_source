export const ASSETS_TYPE = [
    'component',
    'directive',
    'filter'
]