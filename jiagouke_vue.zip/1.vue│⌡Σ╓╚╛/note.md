npm install rollup (打包工具) @babel/core(用babel核心模块) @babel/pres
et-env（babel将高级语法转成低级语法） rollup-plugin-babel(桥梁) rollup-plugin-serve(实现静态服务) cross-env(设置环境变量) -D