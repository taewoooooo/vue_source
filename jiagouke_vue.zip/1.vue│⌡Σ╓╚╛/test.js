(function anonymous() {
    with(this) {
        return _c("div", {
            id: "app",
            style: {
                "color": " red",
                "background": "blue"
            }
        }, _c("p", undefined, _v(_s(name))), _c("span", undefined, _v(_s(age))), _c("ul", undefined, _c("li", undefined, _v(_s(name))), _c("li", undefined, _v(_s(age)))))
    }
})